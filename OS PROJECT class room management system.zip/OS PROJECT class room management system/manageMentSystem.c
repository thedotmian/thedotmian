#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <string.h>
#include <stdbool.h> 
#define MAX_LINE_LENGTH 500
int main() {


int fd[2];
char String[800];
char reardbuffer=pipe(fd);
char readbuffer[800];
int results=pipe(fd);

int selec;
printf("\tpress 1/2/3 \n");
printf("\t1] SignUP \n");
printf("\t2] Login\n");
printf("\t3] Entertainment MODE\n");
scanf("%d", &selec);
if(selec==1){
char name[20],Fname[20],contact[20],id[20],password[20];
int t;
FILE *file;  // Declare a file pointer
file = fopen("SignUP.txt", "a");  // Open the file in append mode

if (file == NULL) {
printf("Error opening the file.\n");
return 1;
}//error will occour in case
printf("enter your name-->");
scanf("%s", name);

printf("enter your father name-->");
scanf("%s", Fname);

printf("enter your contact NO#-->");
scanf("%s", contact);

printf("enter your ID-->");
scanf("%s", id);

printf("enter your password-->");
scanf("%s", password);

if(fork()==0){//child store the given values in file
printf("child created pid is --> %d",getppid());
fprintf(file, "%s,%s,%s,%s,%s,", name,Fname,contact,id,password);  // Write data to the file
}
printf("Data successfully saved\n");

fclose(file);  // Close the file
}//end of if

//-----------------------------------------------------part 2---------------------------------

else if(selec==2){
int selec;
printf("\tLogin As\n");
printf("\t1] Teacher \n");
printf("\t2] Student\n");
printf("\t3] Admin\n");
scanf("%d", &selec);
if(selec==2){
char id[20];
char pass[20];
bool check1=false,check2=false;

printf("\tEnter ID\n");
scanf("%s",id); 
printf("\tEnter Password\n");
scanf("%s",pass); 

FILE *file;
char line[MAX_LINE_LENGTH];
char *token;

// Open the file for reading
file = fopen("SignUP.txt", "r");
if (file == NULL) {
printf("Failed to open the file.\n");
return 1;
}//error will occour if file not found

// Read lines from the file
while (fgets(line, MAX_LINE_LENGTH, file) != NULL) {
token = strtok(line, ",");
while (token != NULL) {

int result = strncmp(token, id, 10);//compareing file data with user input data
int result2 = strncmp(token, pass, 10);//compareing file data with user input data

if(result==0){}
else{
check1=true;
}

if(result2==0){}
else{
check2=true;
}


token = strtok(NULL, ",");
}//end of inner while

if(check1 && check2){
printf("Login Success\n");
printf("\t----------------------------------------------\n");
printf("\t  WELCOME %s",id);
printf("\n\t----------------------------------------------\n");

int selec;
printf("\tpress 1 \n");
printf("\t1] view Announcement \n");
scanf("%d", &selec);
if(selec==1){
FILE *file;
char line[MAX_LINE_LENGTH];
char *token;

// Open the file for reading
file = fopen("announcements.txt", "r");
if (file == NULL) {
printf("Failed to open the file.\n");
return 1;
}

// Read lines from the file
while (fgets(line, MAX_LINE_LENGTH, file) != NULL) {
// Tokenize the line using the delimiter
token = strtok(line, ",");

// Process each token
while (token != NULL) {
// Print the token
printf("%s\n", token);

// Move to the next token
token = strtok(NULL, ",");
}
}

// Close the file
fclose(file);

return 0;
}
break;}//end of students if

else{printf("--------Access Denied---------\n");}//end of else



}//end of outer while

// Close the file
fclose(file);
}//end of inner

else if(selec==1){
char id[20];
char pass[20];
char teacher[7]="teacher";
bool check1=false,check2=false;

printf("\tEnter ID\n");
scanf("%s",id); 
printf("\tEnter Password\n");
scanf("%s",pass); 


int result = strncmp(teacher, id, 10);//compareing file data with user input data
int result2 = strncmp(teacher, pass, 10);//compareing file data with user input data

if(result==0){}
else{
check1=true;
}

if(result2==0){}
else{
check2=true;
}

if(check1 && check2){
printf("\t----------------------------------------------\n");
printf("\t  WELCOME Ms. Noushine");
printf("\n\t----------------------------------------------\n");
int selec;
printf("\tpress 1/2 \n");
printf("\t1] Announcement \n");
printf("\t2] View Studets\n");
scanf("%d", &selec);

if(selec==1){
printf("\t----------------------------------------------\n");
printf("\t  Make Announcement here");
printf("\n\t----------------------------------------------\n");


printf("start writing-->");
scanf("%s", String);

if(results<0){//if it is -1 then error
printf("error creating pipe1\n");
return 1;
}

int childpid=fork();//chiled created
if(childpid==-1){
printf("error in fork()\n");
}

if(childpid==0){
close (fd[0]);
//printf("child reading data and sending to parent\n");
write(fd[1],String,sizeof(String));
return 0;

}
else{
close (fd[1]);
//printf("parent writing in file which is sent by child\n");
read(fd[0],readbuffer,sizeof(readbuffer));
FILE *file;  // Declare a file pointer
file = fopen("announcements.txt", "a");  

if (file == NULL) {
printf("Error opening the file.\n");
return 1;
}//error will occour in case
fprintf(file, "%s ,", readbuffer);  // Write data to the file
}//end of else




}//end of select if

else if(selec==2){

FILE *file;
char line[MAX_LINE_LENGTH];
char *token;

// Open the file for reading
file = fopen("SignUP.txt", "r");
if (file == NULL) {
printf("Failed to open the file.\n");
return 1;
}

// Read lines from the file
while (fgets(line, MAX_LINE_LENGTH, file) != NULL) {
// Tokenize the line using the delimiter
token = strtok(line, ",");

// Process each token
while (token != NULL) {
// Print the token
printf("%s", token);

// Move to the next token
token = strtok(NULL, ",");
printf("  ");
}

}

// Close the file
fclose(file);

return 0;
}//end of teachers select else if


}//end if checks if
else{printf("--------Access Denied---------\n");}

}//end of  teacher selection 



else if(selec==3){
printf("\t----------------------------------------------\n");
printf("\t  ADMINISTRATOR ACCESS ");
printf("\n\t----------------------------------------------\n");

int selec;
printf("\tpress 1/2 \n");
printf("\t1] show all the files \n");
printf("\t2] turn off PC\n");
scanf("%d", &selec);
if(selec==1){system("ls");}
else if(selec==2){system("sleep 5 && sudo shutdown -h now");}
else if (selec==3){system("sudo reboot");}
}//end of login as Admin [3


}//end of outer else if

if(selec==3){
printf("\t----------------------------------------------\n");
printf("\t  Entertainment PlayGround ");
printf("\n\t----------------------------------------------\n");
int selec;
printf("\tpress 1/2/3 \n");
printf("\t1] CowSay \n");
printf("\t2] xCowsay\n");
printf("\t3] Big\n");
printf("\t4] asciiquarium\n");
scanf("%d", &selec);
if(selec==1){system("cowsay \"salam!\"");}
else if(selec==2){system("xcowsay \"Wa Alikum Assalam\"");}
else if(selec==3){ system("toilet \"ENDED\"");}
else if(selec==4){ system("asciiquarium");}
}


return 0;
}//end of main

